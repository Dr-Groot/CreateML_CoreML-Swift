//
//  ViewController.swift
//  ObjectDetectionImage
//
//  Created by Amam Pratap Singh on 24/01/23.
//

import UIKit
import CoreML
import Vision
import ImageIO

class ViewController: UIViewController {

    @IBOutlet var predictionImageView: UIImageView!
    @IBOutlet var imageOptionButtons: [UIButton]!
    @IBOutlet var catLabel: UILabel!
    @IBOutlet var dogLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

        configTheme()
    }

    private func configTheme() {
        predictionImageView.image = UIImage(named: "catDog")
        catLabel.textColor = .black
        dogLabel.textColor = .black
        catLabel.text = "Cat: 0"
        dogLabel.text = "Dog: 0"
    }

//  Image Detection
    private func imageDetection(image: UIImage) {
//      Getting Image
        guard let orientation = CGImagePropertyOrientation(rawValue: UInt32(image.imageOrientation.rawValue)) else { return }
        guard let ciImage = CIImage(image: image) else { fatalError("Unable to create \(CIImage.self) from \(image).") }

        
//      Model
        guard let model = try? VNCoreMLModel(for: AnimalDogCat().model) else { return }

//      Request
        let request = VNCoreMLRequest(model: model, completionHandler: { [weak self] request, error in
            guard let results = request.results else { return }
            DispatchQueue.main.async {
                let firstValue = "\(results[0])"
                if firstValue.contains("Dog") {
                    self?.catLabel.text = "Cat: \(results[1].confidence * 100)"
                    self?.dogLabel.text = "Dog: \(results[0].confidence * 100)"
                } else {
                    self?.catLabel.text = "Cat: \(results[0].confidence * 100)"
                    self?.dogLabel.text = "Dog: \(results[1].confidence * 100)"
                }
            }
        })

//      Request Handler
        try? VNImageRequestHandler(ciImage: ciImage, orientation: orientation).perform([request])
    }

//  Photo option display
    @IBAction func didTapSelectOptionButton(_ sender: UIButton) {
        imageOptionButtons.forEach { (Button) in
            UIView.animate(withDuration: 0.3,animations: {
                Button.isHidden = !Button.isHidden
                self.view.layoutIfNeeded()
            })
        }
    }

    @IBAction func didTapCamerButton(_ sender: UIButton) {
        let cameraPickerVC = UIImagePickerController()
        cameraPickerVC.sourceType = .camera
        cameraPickerVC.allowsEditing = true
        cameraPickerVC.delegate = self
        hideImageOptionButtons()
        present(cameraPickerVC, animated: true)
    }

    @IBAction func didTapGalleryButton(_ sender: UIButton) {
        let imagePickerVC = UIImagePickerController()
        imagePickerVC.sourceType = .photoLibrary
        imagePickerVC.delegate = self
        imagePickerVC.allowsEditing = true
        hideImageOptionButtons()
        present(imagePickerVC, animated: true)
    }

    @IBAction func didTapRemovePhotoButton(_ sender: UIButton) {
        predictionImageView.image = UIImage(named: "catDog")
        catLabel.text = "Cat: 0"
        dogLabel.text = "Dog: 0"
    }

    private func hideImageOptionButtons() {
        imageOptionButtons.forEach { (Buttons) in
            UIView.animate(withDuration: 0.3, animations: {
                Buttons.isHidden = !Buttons.isHidden
                self.view.layoutIfNeeded()
            })
        }
    }
}

extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
//  Picker controller to select image from gallery or camera
    func imagePickerController(
        _ picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[UIImagePickerController.InfoKey(rawValue: "UIImagePickerControllerEditedImage")] as? UIImage {
                predictionImageView.image = image
                imageDetection(image: image)
            }
            picker.dismiss(animated: true) {
                self.dismiss(animated: true)
            }
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
